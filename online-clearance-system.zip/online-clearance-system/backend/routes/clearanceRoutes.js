const express = require('express');
const router = express.Router();
const clearanceController = require('../controllers/clearanceController');
const { verifyToken, authorizeRoles } = require('../middleware/authMiddleware');

// Route 1: Start Clearance (Renamed to match Frontend)
router.post('/start', verifyToken, authorizeRoles('student'), clearanceController.createClearanceRequest);

// Route 2: View Status (Only Students)
router.get('/status', verifyToken, authorizeRoles('student'), clearanceController.getStudentClearanceStatus);

module.exports = router;