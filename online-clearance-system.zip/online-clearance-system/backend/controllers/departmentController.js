const sql = require('../config/db');

// 1. View Pending Requests (Work to do)
exports.getPendingRequests = async (req, res) => {
  try {
    const userId = req.user.id;
    const officer = await sql`SELECT department_id FROM users WHERE id = ${userId}`;
    if (officer.length === 0 || !officer[0].department_id) {
      return res.status(403).json({ message: 'You are not assigned to a department' });
    }
    const myDeptId = officer[0].department_id;

    const requests = await sql`
      SELECT 
        cs.id AS status_id, 
        s.full_name, 
        s.registration_number, 
        cs.status, 
        cs.updated_at
      FROM clearance_status cs
      JOIN clearance_requests cr ON cs.clearance_request_id = cr.id
      JOIN students s ON cr.student_id = s.id
      WHERE cs.department_id = ${myDeptId} 
      AND cs.status = 'pending'
    `;

    res.json(requests);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Fetch failed' });
  }
};

// 2. View History (Work already done - NEW FUNCTION)
exports.getHistory = async (req, res) => {
  try {
    const userId = req.user.id;
    const officer = await sql`SELECT department_id FROM users WHERE id = ${userId}`;
    const myDeptId = officer[0].department_id;

    // Fetch requests that are NOT pending (Approved or Rejected)
    const history = await sql`
      SELECT 
        cs.id AS status_id, 
        s.full_name, 
        s.registration_number, 
        cs.status, 
        cs.updated_at
      FROM clearance_status cs
      JOIN clearance_requests cr ON cs.clearance_request_id = cr.id
      JOIN students s ON cr.student_id = s.id
      WHERE cs.department_id = ${myDeptId} 
      AND cs.status != 'pending'
      ORDER BY cs.updated_at DESC
    `;

    res.json(history);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Fetch failed' });
  }
};

// 3. Approve/Reject (Update Status)
exports.updateStatus = async (req, res) => {
  try {
    const { status_id, status, comment } = req.body;
    const userId = req.user.id;

    if (!status) return res.status(400).json({ message: 'Status is required' });

    await sql`
      UPDATE clearance_status
      SET status = ${status}, comment = ${comment}, updated_at = NOW()
      WHERE id = ${status_id}
    `;

    // Log the action
    try {
      const user = await sql`SELECT email FROM users WHERE id = ${userId}`;
      const actorEmail = user.length > 0 ? user[0].email : 'Unknown';

      await sql`
        INSERT INTO audit_logs (actor_email, action, details)
        VALUES (${actorEmail}, ${status.toUpperCase()}, ${`Updated request ${status_id} to ${status}`})
      `;
    } catch (logErr) {
      console.error("⚠️ Audit Log failed:", logErr.message);
    }

    res.json({ message: `Student ${status} successfully` });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Update failed' });
  }
};