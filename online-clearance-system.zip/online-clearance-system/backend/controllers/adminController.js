const sql = require('../config/db');
const bcrypt = require('bcryptjs'); 

// 1. Get All System Users
exports.getUsers = async (req, res) => {
  try {
    const users = await sql`
      SELECT u.id, u.email, u.role, d.name as dept_name 
      FROM users u
      LEFT JOIN departments d ON u.department_id = d.id
      ORDER BY u.role, u.email
    `;
    res.json(users);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server Error' });
  }
};

// 2. View All Clearance Requests
exports.getAllRequests = async (req, res) => {
  try {
    const report = await sql`
      SELECT 
        s.full_name, s.registration_number, cr.id AS request_id,
        COUNT(cs.id) AS total_depts,
        COUNT(CASE WHEN cs.status = 'approved' THEN 1 END) AS approved_count,
        COUNT(CASE WHEN cs.status = 'rejected' THEN 1 END) AS rejected_count
      FROM clearance_requests cr
      JOIN students s ON cr.student_id = s.id
      JOIN clearance_status cs ON cs.clearance_request_id = cr.id
      GROUP BY s.full_name, s.registration_number, cr.id
    `;
    res.json(report);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Report failed' });
  }
};

// 3. Get Graduates
exports.getClearedStudents = async (req, res) => {
  try {
    const graduates = await sql`
      SELECT s.full_name, s.registration_number, s.program
      FROM clearance_requests cr
      JOIN students s ON cr.student_id = s.id
      WHERE NOT EXISTS (
        SELECT 1 FROM clearance_status cs
        WHERE cs.clearance_request_id = cr.id
        AND cs.status != 'approved'
      )
    `;
    res.json(graduates);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Fetch failed' });
  }
};

// 4. Create New User
exports.addUser = async (req, res) => {
  try {
    const { email, password, role, department_id, full_name, reg_number } = req.body;
    const adminId = req.user.id; 
    
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // A. Create User Login
    const newUser = await sql`
      INSERT INTO users (email, password, role, department_id)
      VALUES (${email}, ${hashedPassword}, ${role}, ${department_id || null})
      RETURNING id
    `;
    const userId = newUser[0].id;

    // B. If Student, create Student Profile
    if (role === 'student') {
      await sql`
        INSERT INTO students (user_id, full_name, registration_number)
        VALUES (${userId}, ${full_name}, ${reg_number})
      `;
    }

    // C. LOG THE ACTION (Safe Mode)
    try {
        const admin = await sql`SELECT email FROM users WHERE id = ${adminId}`;
        const adminEmail = admin.length > 0 ? admin[0].email : 'Unknown';

        await sql`
        INSERT INTO audit_logs (actor_email, action, details)
        VALUES (${adminEmail}, 'CREATE_USER', ${`Created new ${role}: ${email}`})
        `;
    } catch (logErr) {
        console.error("⚠️ Audit Log failed:", logErr.message);
    }

    res.json({ message: 'User created successfully' });
  } catch (err) {
    console.error("❌ Add User Error:", err);
    
    // CHECK FOR SPECIFIC ERRORS
    if (err.code === '23505') { // Postgres code for "Unique Violation"
      if (err.constraint && err.constraint.includes('department_id')) {
         return res.status(400).json({ error: 'That Department already has a staff member!' });
      }
      return res.status(400).json({ error: 'Email already exists.' });
    }
    
    // Return the ACTUAL error message for debugging
    res.status(500).json({ error: err.message });
  }
};

// 5. Get System Logs
exports.getSystemLogs = async (req, res) => {
  try {
    const logs = await sql`SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 50`;
    res.json(logs);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Fetch logs failed' });
  }
};

// 6. Get Departments (NEW FUNCTION - Fixes UUID Error)
exports.getDepartments = async (req, res) => {
  try {
    const depts = await sql`SELECT id, name FROM departments ORDER BY name`;
    res.json(depts);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Fetch departments failed' });
  }
};