const sql = require('../config/db');

// 1. Submit Clearance Request
exports.createClearanceRequest = async (req, res) => {
  try {
    const userId = req.user.id; 

    // A. Find the Student ID linked to this User
    const students = await sql`SELECT id FROM students WHERE user_id = ${userId}`;
    
    // Safety Check: Did the Admin create the student profile correctly?
    if (students.length === 0) {
      return res.status(404).json({ message: 'Student profile missing. Please contact Admin.' });
    }
    const studentId = students[0].id;

    // B. Check if request already exists
    const existing = await sql`SELECT * FROM clearance_requests WHERE student_id = ${studentId}`;
    if (existing.length > 0) return res.status(400).json({ message: 'Request already exists' });

    // C. Create the Request
    const newReq = await sql`
      INSERT INTO clearance_requests (student_id, status)
      VALUES (${studentId}, 'Pending')
      RETURNING id
    `;
    const requestId = newReq[0].id;

    // D. Get All Departments
    const departments = await sql`SELECT id FROM departments`;

    // E. Create a Status Row for EACH Department
    for (const dept of departments) {
      await sql`
        INSERT INTO clearance_status (clearance_request_id, department_id, status)
        VALUES (${requestId}, ${dept.id}, 'pending')
      `;
    }

    res.status(201).json({ message: 'Clearance initiated successfully!' });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server Error' });
  }
};

// 2. Get My Status
exports.getStudentClearanceStatus = async (req, res) => {
  try {
    const userId = req.user.id;

    // A. Find Student
    const students = await sql`SELECT id FROM students WHERE user_id = ${userId}`;
    if (students.length === 0) return res.json([]); // Return empty if no profile
    const studentId = students[0].id;

    // B. Get Status List
    // CHANGED: 'd.name as dept_name' matches your React Dashboard code
    const statusList = await sql`
      SELECT d.name as dept_name, cs.status, cs.comment, cs.updated_at
      FROM clearance_status cs
      JOIN clearance_requests cr ON cs.clearance_request_id = cr.id
      JOIN departments d ON cs.department_id = d.id
      WHERE cr.student_id = ${studentId}
    `;

    res.json(statusList);

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server Error' });
  }
};