import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { FaUserGraduate, FaRocket, FaCheckCircle, FaClock, FaSignOutAlt, FaBell } from 'react-icons/fa';
import './StudentDashboard.css'; // Connects the new CSS

const StudentDashboard = () => {
  const [clearanceStatus, setClearanceStatus] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchStatus();
  }, []);

  const fetchStatus = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/clearance/status', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setClearanceStatus(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleStartClearance = async () => {
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:5000/api/clearance/start', {}, {
        headers: { Authorization: `Bearer ${token}` }
      });
      alert('Clearance Process Started!');
      fetchStatus();
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to start');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    navigate('/');
  };

  // Calculate Stats
  const totalDepts = clearanceStatus.length;
  const approvedCount = clearanceStatus.filter(c => c.status === 'approved').length;
  const pendingCount = clearanceStatus.filter(c => c.status === 'pending').length;

  return (
    <div className="student-container">
      {/* SIDEBAR */}
      <div className="student-sidebar">
        <div className="student-brand">
          <FaUserGraduate /> My Portal
        </div>
        
        <div className="nav-link active"><FaRocket /> My Clearance</div>
        <div className="nav-link"><FaCheckCircle /> History</div>
        
        <div style={{ marginTop: 'auto' }}>
          <div className="nav-link" onClick={handleLogout}>
            <FaSignOutAlt /> Logout
          </div>
        </div>
      </div>

      {/* MAIN CONTENT */}
      <div className="student-main">
        {/* HEADER */}
        <div className="student-header">
          <div style={{ fontWeight: '600', color: '#2c3e50' }}>Student Dashboard</div>
          <div className="student-profile">
            <FaBell size={18} color="#a4b0be" style={{ cursor: 'pointer' }}/>
            <div style={{ width: '35px', height: '35px', borderRadius: '50%', background: '#dfe6e9' }}></div>
          </div>
        </div>

        <div className="student-content">
          {/* WELCOME AREA */}
          <div className="welcome-section">
            <div>
              <h2 style={{margin: 0, color: '#2c3e50'}}>Clearance Overview</h2>
              <p style={{margin: '5px 0 0', color: '#a4b0be'}}>Track your graduation progress here.</p>
            </div>
            {totalDepts === 0 && (
              <button className="start-btn" onClick={handleStartClearance}>
                <FaRocket /> Start Clearance Process
              </button>
            )}
          </div>

          {/* STATS CARDS */}
          <div className="progress-grid">
            <div className="progress-card">
              <div className="icon-holder bg-purple"><FaUserGraduate /></div>
              <div>
                <h2 style={{margin: 0, fontSize: '28px'}}>{totalDepts}</h2>
                <span style={{color: '#a4b0be', fontSize: '14px'}}>Total Departments</span>
              </div>
            </div>

            <div className="progress-card">
              <div className="icon-holder bg-green"><FaCheckCircle /></div>
              <div>
                <h2 style={{margin: 0, fontSize: '28px'}}>{approvedCount}</h2>
                <span style={{color: '#a4b0be', fontSize: '14px'}}>Cleared</span>
              </div>
            </div>

            <div className="progress-card">
              <div className="icon-holder bg-yellow"><FaClock /></div>
              <div>
                <h2 style={{margin: 0, fontSize: '28px'}}>{pendingCount}</h2>
                <span style={{color: '#a4b0be', fontSize: '14px'}}>Pending</span>
              </div>
            </div>
          </div>

          {/* STATUS TABLE */}
          <div className="status-table-container">
            <h3 style={{marginBottom: '20px', color: '#2c3e50'}}>Department Status</h3>
            
            {totalDepts === 0 ? (
              <div style={{textAlign: 'center', padding: '40px', color: '#a4b0be'}}>
                You haven't started the clearance process yet. <br/>
                Click the button above to begin!
              </div>
            ) : (
              <table className="status-table">
                <thead>
                  <tr>
                    <th>Department</th>
                    <th>Status</th>
                    <th>Officer Comment</th>
                    <th>Last Update</th>
                  </tr>
                </thead>
                <tbody>
                  {clearanceStatus.map((item, index) => (
                    <tr key={index}>
                      <td style={{fontWeight: '600'}}>{item.dept_name}</td>
                      <td>
                        <span className={`status-badge badge-${item.status}`}>
                          {item.status}
                        </span>
                      </td>
                      <td>{item.comment || '-'}</td>
                      <td>{new Date(item.updated_at).toLocaleDateString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;