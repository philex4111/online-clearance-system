import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { FaBuilding, FaClipboardList, FaSignOutAlt, FaBell, FaSearch, FaCheckCircle, FaHistory } from 'react-icons/fa';
import './DepartmentDashboard.css';

const DepartmentDashboard = () => {
  const [requests, setRequests] = useState([]); // Pending List
  const [history, setHistory] = useState([]);   // History List
  const [activeTab, setActiveTab] = useState('requests'); // Controls which view is shown
  const navigate = useNavigate();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const token = localStorage.getItem('token');
      const headers = { Authorization: `Bearer ${token}` };

      // 1. Get Pending
      const resPending = await axios.get('http://localhost:5000/api/department/pending', { headers });
      setRequests(resPending.data);

      // 2. Get History (NEW)
      const resHistory = await axios.get('http://localhost:5000/api/department/history', { headers });
      setHistory(resHistory.data);

    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdate = async (id, status) => {
    // Confirmation for changing history
    if (activeTab === 'history') {
      if (!window.confirm(`Are you sure you want to change this student to ${status}?`)) return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.put('http://localhost:5000/api/department/update', 
        { status_id: id, status, comment: status === 'approved' ? 'Cleared' : 'See office' },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert(`Student updated to ${status}`);
      fetchData(); // Refresh both lists
    } catch (err) {
      alert('Update Failed');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    navigate('/');
  };

  // --- RENDER TABLES ---
  const renderTable = (data, showActions = true) => (
    <div className="request-table-container">
      <h3 style={{marginBottom: '20px', color: '#2c3e50'}}>
        {activeTab === 'requests' ? 'Incoming Clearance Requests' : 'Processed History'}
      </h3>
      
      {data.length === 0 ? (
        <p style={{color: '#a4b0be', fontStyle: 'italic'}}>No records found.</p>
      ) : (
        <table className="dept-table">
          <thead>
            <tr>
              <th>Student Name</th>
              <th>Reg. Number</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.map((req) => (
              <tr key={req.status_id}>
                <td style={{fontWeight: '600'}}>{req.full_name}</td>
                <td>{req.registration_number}</td>
                <td>
                   <span style={{
                     fontWeight:'bold', 
                     color: req.status === 'approved' ? 'green' : (req.status === 'rejected' ? 'red' : 'orange')
                   }}>
                     {req.status.toUpperCase()}
                   </span>
                </td>
                <td>
                  {/* Show buttons even in history so you can change your mind */}
                  <button 
                    className="action-btn approve-btn"
                    onClick={() => handleUpdate(req.status_id, 'approved')}
                  >
                    Approve
                  </button>
                  <button 
                    className="action-btn reject-btn"
                    onClick={() => handleUpdate(req.status_id, 'rejected')}
                  >
                    Reject
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );

  return (
    <div className="dept-container">
      {/* SIDEBAR */}
      <div className="dept-sidebar">
        <div className="dept-brand"><FaBuilding /> Dept. Panel</div>
        
        <div 
          className={`nav-item ${activeTab==='requests'?'active':''}`} 
          onClick={() => setActiveTab('requests')}
        >
          <FaClipboardList /> Requests
        </div>

        <div 
          className={`nav-item ${activeTab==='history'?'active':''}`} 
          onClick={() => setActiveTab('history')}
        >
          <FaHistory /> History
        </div>
        
        <div style={{ marginTop: 'auto' }}>
          <div className="nav-item" onClick={handleLogout}><FaSignOutAlt /> Logout</div>
        </div>
      </div>

      {/* MAIN CONTENT */}
      <div className="dept-main">
        <div className="dept-header">
          <div style={{ fontWeight: '600', color: '#2c3e50' }}>Department Officer</div>
          <div className="dept-profile">
            <FaBell size={18} color="#a4b0be" />
            <div style={{ width: '35px', height: '35px', borderRadius: '50%', background: '#dfe6e9' }}></div>
          </div>
        </div>

        <div className="dept-content">
          {/* STATS */}
          <div className="dept-stats">
            <div className="stat-box">
              <div className="icon-wrapper orange-bg"><FaClipboardList /></div>
              <div>
                <h2 style={{margin: 0, fontSize: '28px'}}>{requests.length}</h2>
                <span style={{color: '#a4b0be', fontSize: '14px'}}>Pending</span>
              </div>
            </div>
            
            <div className="stat-box">
              <div className="icon-wrapper blue-bg"><FaCheckCircle /></div>
              <div>
                <h2 style={{margin: 0, fontSize: '28px'}}>{history.length}</h2>
                <span style={{color: '#a4b0be', fontSize: '14px'}}>Processed</span>
              </div>
            </div>
          </div>

          {/* VIEW SWITCHER */}
          {activeTab === 'requests' && renderTable(requests)}
          {activeTab === 'history' && renderTable(history)}

        </div>
      </div>
    </div>
  );
};

export default DepartmentDashboard;